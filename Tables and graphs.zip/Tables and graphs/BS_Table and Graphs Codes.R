#Fama Net

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat1[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat2[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
  BS_mat[i,1]<-ux[i]
  BS_mat[i,2]<-mean(dat_1f$alpha)
  BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
  BS_mat[i,8]<-mean(dat_1f$t_alpha)
  BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.csv")




dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")

for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.csv")


#Fama Net

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.csv")


#Fama Net

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")




for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.csv")


#Fama Net

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")




for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.csv")



#Fama Net

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_BM_LCV.dta")
dat2<-dat2[1:177500,]
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")

for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.csv")


#Fama Gross

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat1[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat2[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.csv")




dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")

for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.csv")


#Fama Gross

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.csv")


#Fama Gross

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")




for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.csv")


#Fama Gross

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_BM_LCV.dta")
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")




for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.csv")



#Fama Gross

dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_MK_LCV.dta")
dat2<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_1F_BM_LCV.dta")
dat2<-dat2[1:177500,]
dat3<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/BS_4F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=17))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95","alpha4FBM_Mean","alpha4FBM_95","talpha4FBM_Mean","talpha4FBM_95")

for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  dat_4f<-dat[dat1$Fund==ux[i],]
  dat_4f<-na.omit(dat_4f)
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  dat_4f_bm<-dat3[dat3$Fund==ux[i],]
  dat_4f_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  if(nrow(dat_4f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-NA
    BS_mat[i,5]<-NA
    BS_mat[i,10]<-NA
    BS_mat[i,11]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
  
  if(nrow(dat_4f_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-NA
    BS_mat[i,15]<-NA
    BS_mat[i,16]<-NA
    BS_mat[i,17]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,14]<-mean(dat_bm$alpha)
    BS_mat[i,15]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,16]<-mean(dat_bm$t_alpha)
    BS_mat[i,17]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.csv")




#GRAPHS
#LCV
#NET
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
datBM4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()


#GROSS
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_BM_LCV.dta"))
datBM4F<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()





#GRAPHS
#LCV
#NET
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
datBM4F<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()


#GROSS
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_BM_LCV.dta"))
datBM4F<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()




#GRAPHS
#LCV
#NET
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
datBM4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()


#GROSS
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_BM_LCV.dta"))
datBM4F<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()



#GRAPHS
#LCV
#NET
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
datBM4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()


#GROSS
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_BM_LCV.dta"))
datBM4F<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()




#GRAPHS
#LCV
#NET
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
datBM4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()


#GROSS
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_BM_LCV.dta"))
datBM4F<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()




#GRAPHS
#LCV
#NET
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_NET/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
datBM4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()


#GROSS
dat<-na.omit(read_dta("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Table/FAMA_GROSS/LCV.dta"))
datBM<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_BM_LCV.dta"))
datBM4F<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_BM_LCV.dta"))
dat1f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_1F_MK_LCV.dta"))
dat4f<-na.omit(read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_GROSS/ACT_4F_MK_LCV.dta"))

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_alpha.jpg")
plot(ecdf(dat1f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_1f_talpha.jpg")
plot(ecdf(dat1f$t_alpha),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_alpha.jpg")
plot(ecdf(dat4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_4f_talpha.jpg")
plot(ecdf(dat4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_alpha.jpg")
plot(ecdf(datBM$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_talpha.jpg")
plot(ecdf(datBM$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM 4F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_alpha.jpg")
plot(ecdf(datBM4f$alpha),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM 4F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/LCV_bm_4f_talpha.jpg")
plot(ecdf(datBM4f$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()




#FULL
#NET

#dat<-na.read_dta(“D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_LUCK_SKILL_EACH_FUND/NET/FULL.dta”)
dat<-na.omit(FULL)

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/FULL_1f_alpha.jpg")
plot(ecdf(dat$alpha1F),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha (net of expenses) using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/FULL_1f_talpha.jpg")
plot(ecdf(dat$talpha1F),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha (net of expenses) using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/FULL_4f_alpha.jpg")
plot(ecdf(dat$alpha4F),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha (net of expenses) using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/FULL_4f_talpha.jpg")
plot(ecdf(dat$talpha4F),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha (net of expenses) using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/FULL_bm_alpha.jpg")
plot(ecdf(dat$alphaBM),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha (net of expenses) using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/NET/FULL_bm_talpha.jpg")
plot(ecdf(dat$talphaBM),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha (net of expenses) using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()




#FULL
#GROSS

#dat<-read_dta(“D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_LUCK_SKILL_EACH_FUND/GROSS/FULL.dta”)
dat<-na.omit(FULL)

#1 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/FULL_1f_alpha.jpg")
plot(ecdf(dat$alpha1F),xlim=c(-0.02,0.02),main="",xlab="",ylab="")
lines(ecdf(dat$alpha1F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha (net of expenses) using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#1 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/FULL_1f_talpha.jpg")
plot(ecdf(dat$talpha1F),xlim=c(-4,4))   
lines(ecdf(dat$talpha1F_95),col="red",main="",xlab="",ylab="")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha (net of expenses) using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#4 F alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/FULL_4f_alpha.jpg")
plot(ecdf(dat$alpha4F),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor alpha (net of expenses) using Market Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#4 F talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/FULL_4f_talpha.jpg")
plot(ecdf(dat$talpha4F),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talpha4F_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 4 Factor t-stat of alpha (net of expenses) using Market Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#BM alpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/FULL_bm_alpha.jpg")
plot(ecdf(dat$alphaBM),xlim=c(-0.02,0.02),main="",xlab="",ylab="")   
lines(ecdf(dat$alphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor alpha (net of expenses) using Style Benchmark",xlab="alpha",ylab="Percentile")
dev.off()

#BM talpha
jpeg("D:/PhD/Research MG/RESULTS_BS/Q1_DoesItMatter/BS/BS/BS_Graph/FAMA_NEW/GROSS/FULL_bm_talpha.jpg")
plot(ecdf(dat$talphaBM),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat$talphaBM_95),col="red")
legend(x="topleft", legend=c("Actual", "Simulated at 95th Pct"),fill = c("black","red"))
title(main = "CDF of 1 Factor t-stat of alpha (net of expenses) using Style Benchmark",xlab="t-alpha",ylab="Percentile")
dev.off()

#####################################
#####################################
#NEW APPROACH
#FULL
#MK
dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_MK_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_MK_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_MK_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_MK_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_MK_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_MK_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)

dat_sim<-read.csv("D:/PhD/Research MG/FF Bootstrap/FAMA_FRENCH_PAPER_TABLE_3/GROSS/BS_4F_MK.csv")
sim_t_95<-t(dat_sim[15,])
sim_t_95<-sim_t_95[-1]
sim_t_5<-t(dat_sim[5,])
sim_t_5<-sim_t_5[-1]
jpeg("D:/PhD/Research MG/FF Bootstrap/FAMA_FRENCH_PAPER_TABLE_3/GROSS/FULL_MK_talpha.jpg")
plot(ecdf(dat$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(sim_t_95),col="red")
lines(ecdf(sim_t_5),col="red")


#BM
dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_BM_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_BM_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_BM_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_BM_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_BM_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_GROSS/ACT_4F_BM_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)

dat_sim<-read.csv("D:/PhD/Research MG/FF Bootstrap/FAMA_FRENCH_PAPER_TABLE_3/GROSS/BS_4F_BM.csv")
sim_t_95<-t(dat_sim[15,])
sim_t_95<-sim_t_95[-1]
sim_t_5<-t(dat_sim[5,])
sim_t_5<-sim_t_5[-1]
jpeg("D:/PhD/Research MG/FF Bootstrap/FAMA_FRENCH_PAPER_TABLE_3/GROSS/FULL_BM_talpha.jpeg")
plot(ecdf(dat$t_alpha),xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(sim_t_95),col="red")
lines(ecdf(sim_t_5),col="red")



#############################################
#new method

#merge data
dat<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_BM_LCV.dta")
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_BM_LCV.dta")
dat<-rbind(dat,dat1)
rm(dat1)
write_dta(dat,"D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/ACT_4F_BM_FULL.dta")

#find pct
dat1<-read_dta("D:/PhD/Research MG/FF Bootstrap/BS_FAMA_NET/BS_1F_BM_LCV.dta")
dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]

dat_pct<-dat %>%
  group_by(Fund)%>%
  summarise(quantile(t_alpha,0.95),quantile(t_alpha,0.05))
dat_pct<-rename(dat_pct,"pct_95"= `quantile(t_alpha, 0.95)`)
dat_pct<-rename(dat_pct,"pct_5"= `quantile(t_alpha, 0.05)`)
write_dta(dat_pct,"D:/PhD/Research MG/Skewness/FAMA_BS_NET/PCT TABLE/1F_BM_LCV.dta")


#plot graphs
dat_act<-read_dta("D:/PhD/Research MG/Skewness/FAMA_BS_NET/ACT/ACT_1F_BM_FULL.dta")
dat_pct<-read_dta("D:/PhD/Research MG/Skewness/FAMA_BS_NET/PCT TABLE/1F_BM_FULL.dta")
jpeg("D:/PhD/Research MG/Skewness/FAMA_BS_NET/FF_ACTUAL_ZERO_ALPHA/1F_BM_FULL.jpg")
plot(ecdf(dat_act$t_alpha),lwd=2,xlim=c(-4,4),main="",xlab="",ylab="")   
lines(ecdf(dat_pct$pct_95),lty=3,lwd=2,col="red")
lines(ecdf(dat_pct$pct_5),lty=3,lwd=2,col="red")
title(main="CDF of t-alpha using Style benchmark", xlab="t_alpha",ylab="pct")



#plot alpha graphs for mkt and style BM

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/FULL.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/FULL.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for all funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/FULL.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/FULL.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for all funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()



dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()


dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()



dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()


dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()



dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()



dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()


dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/NET/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of net alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/ALPHAS/GROSS/LCV.dta")
jpeg("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/LCV.jpg")
plot(ecdf(dat$alpha_mk),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat$alpha_st),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MK", "alpha_ST"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas for LCV funds", xlab="alpha",ylab="pct")
dev.off()





###########################################################################
#Draw alphas BM versus MK

path_gross<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/GROSS/"
path_net<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/GRAPHS/ALPHA/NET/"

style<-c("Large Blend_2024-09-08","Large Growth_2024-09-08","Large Value_2024-09-08","Mid Blend_2024-09-08","Mid Growth_2024-09-08","Mid Value_2024-09-08","Small Blend_2024-09-08","Small Growth_2024-09-08","Small Value_2024-09-08")
path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/GROSS/ST BM/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/GROSS/"


dat_mk<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:9)
{
  
  file_name <- paste0(path1, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat_mk<-rbind(dat_mk,dat1)
  rm(dat1)
  
}


dat_st<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:9)
{
  
  file_name <- paste0(path2, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat_st<-rbind(dat_st,dat1)
  rm(dat1)
  
}


dynamic_path<-paste0(path_gross,"FULL", ".jpg")
jpeg(dynamic_path)
plot(ecdf(dat_mk$alpha),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
lines(ecdf(dat_st$alpha),lty=3,lwd=2,col="red")
legend("topleft", legend = c("alpha_MB", "alpha_SB"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas", xlab="alpha",ylab="pct")
dev.off()

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/NET/ST BM/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/NET/"


dat_mk<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:9)
{
  
  file_name <- paste0(path1, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat_mk<-rbind(dat_mk,dat1)
  rm(dat1)
  
}


dat_st<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:9)
{
  
  file_name <- paste0(path2, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat_st<-rbind(dat_st,dat1)
  rm(dat1)
  
}


dynamic_path<-paste0(path_net,"FULL", ".jpg")
jpeg(dynamic_path)
plot(ecdf(dat_mk$alpha),lwd=2,xlim=c(-0.01,0.01),main="",xlab="",ylab="")   
plot(ecdf(dat_st$alpha),lwd=2,col="red")
legend("topleft", legend = c("alpha_MB", "alpha_SB"), col = c("black", "red"), pch = c(16, 17), lty = 1)
title(main="CDF of gross alphas", xlab="alpha",ylab="pct")
dev.off()

dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/GROSS/ST BM/Mid Value_2024-09-08.dta")
dat1<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/GROSS/Mid Value_2024-09-08.dta")

t.test(dat$alpha,(dat1$alpha/100),paired=TRUE)
summary(dat$alpha)
summary(dat1$alpha)



##############################################################

#MERGE THE BOOTSTRAPS (2000) AND CREATE THE PCT TABLE FOR EACH BOOTSTRAP
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap/FF/BS/NET/BS_NET_ST_10k.dta")
act<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap/FF/ACTUAL/GROSS/ACT_GROSS_ST_1.dta")
library(dplyr)


dat1<- dat %>%
  group_by(row) %>%
  summarize(
    percentile = c(seq(0.05, 0.95, by = 0.05), 0.96, 0.97, 0.98, 0.99),
    value = map_dbl(percentile, ~ quantile(t_alpha, ., na.rm = TRUE))
  )


dat1<-data.frame(dat1)

dat3<-matrix(nrow=23,ncol=3)
colnames(dat3)<-c("Act","Sim","less_act")
rownames(dat3)<-c("5","10","15","20","25","30","35","40","45","50","55","60","65","70","75","80","85","90","95","96","97","98","99")
pct<-unique(dat1$percentile)
for (i in 1:23)
{
  dat3[i,2]<-round(mean(na.omit(dat1[dat1$percentile==pct[i],]$value)),2)
}
dat3[, 1] <- act %>%
  summarise(
    value = list(map_dbl(
      c(seq(0.05, 0.95, by = 0.05), 0.96, 0.97, 0.98, 0.99),
      ~ quantile(t_alpha, .x, na.rm = TRUE)
    ))
  ) %>%
  pull(value) %>%
  unlist()

dat3<-data.frame(dat3)

for (i in 1:length(pct))
{
  df<-dat1[dat1$percentile==pct[i],]
  dat3[i,3]<-(sum(ifelse(dat3[i,1]>df$value,1,0))/10000)*100
}

write_dta(dat3,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/PCT TABLE PER BOOTSTRAP/FF_NET_ST_10K.dta")
####################################################################################################################

#USE THE MERGED BOOTSTRAPS (2000) AND CREATE THE PCT TABLE FOR EACH FUND
library(haven)
dat<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap/FF/BS/NET/BS_NET_ST_10K.dta")
act<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap/FF/ACTUAL/NET/ACT_NET_ST.dta")

  dat1<- dat %>%
    group_by(Fund) %>%
    summarize(
      p95 = map_dbl(0.95, ~ quantile(t_alpha, ., na.rm = TRUE)),
      p5=map_dbl(0.05, ~ quantile(t_alpha, ., na.rm = TRUE)
      )
    )
  

dat3<-dat[,c("Fund","style")]
dat3<- dat3 %>% distinct(Fund, style, .keep_all = TRUE)

dat1<-merge(dat1, act, by = "Fund", all.x = TRUE)
dat1<-merge(dat1, dat3, by = "Fund", all.x = TRUE)

dat1$skill<-ifelse(dat1$t_alpha>dat1$p95,1,0)
dat1$neg_skill<-ifelse(dat1$t_alpha<dat1$p5,1,0)

write_dta(dat1,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/PCT TABLE PER FUND/FF_GROSS_MK_10K.dta")

##################################################################
#single fund graphs
library(haven)
dat<-read_dta("D:/PhD/Research MG/BS_HL_NET_ST_10k.dta")
act_M<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/HL Bootstrap/ACTUAL/NET/ACT_NET_ST.dta")


for (i in 1:7)
{
  p<-c(1, 5, 10, 50, 90, 95, 99)
  
  act_M$rank <- ecdf(act_M$alpha)(act_M$alpha)
  act_M<-act_M[order(act_M$rank), ]
  val=act_M[act_M$rank>=(p[i]/100),]$Fund[1]
  #s=act_M[act_M$rank>=(p[i]/100),]$style[1]
  
  dat_b<-dat[dat$Fund==val,]
  dat_b<-dat_b[!is.na(dat_b$t_alpha),]
  dat_b<-dat_b[dat_b$R_sqr!=1,]
  a<-rep(act_M[act_M$Fund==val,]$t_alpha,100)
  n<-paste("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/GRAPHS/PDF/HL_NET_MK_",p[i],".jpg")
  NF<-rep(quantile(dat_b$t_alpha,0.95, na.rm=TRUE),100)
  F<-rep(quantile(dat_b$t_alpha,0.05, na.rm=TRUE),100)
  
  jpeg(n)
  plot(density(dat_b$t_alpha, na.rm = TRUE),main="",xlab="",ylab="",lwd=2,xlim=c(-4,7))
  abline(v=a, col='blue', lwd=4, lty=2)
  abline(v=NF, col='red',lwd=2,lty=4)
  abline(v=F, col='red',lwd=2, lty=4)
  legend("topright", legend = c("pdf", "confidence bands", "actual"), col = c("black", "red", "blue"), lty = c(1,2,4), lwd=2, cex=0.7)
  t<-paste0("Fund at ", p[i], "th Pct")
  title(main=t , xlab="t_alpha", ylab="density")
  dev.off()
  #i<-i+1
}

rm(a,dat_b)
a<-rep(act_M[order(act_M$alpha),]$t_alpha[1],100)
b_f<-act_M[order(act_M$alpha),]$Fund[1]
dat_b<-dat[dat$Fund==b_f,]
NF<-rep(quantile(dat_b$t_alpha,0.95, na.rm=TRUE),100)
F<-rep(quantile(dat_b$t_alpha,0.05, na.rm=TRUE),100)
n<-paste("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/GRAPHS/PDF/FF_GROSS_ST_10K_bottom_fund.jpg")
jpeg(n)
plot(density(dat_b$t_alpha, na.rm = TRUE),main="",xlab="",ylab="",lwd=2)
abline(v=a, col='blue', lwd=4, lty=2)
abline(v=NF, col='red',lwd=2,lty=4)
abline(v=F, col='red',lwd=2, lty=4)
legend("topright", legend = c("pdf", "confidence bands", "actual"), col = c("black", "red", "blue"), lty = c(1,2,4), lwd=2, cex=0.7)
t<-paste0("The bottom fund")
title(main=t , xlab="t_alpha", ylab="density")
dev.off()

rm(a,dat_b)
a<-rep(act_M[order(act_M$alpha),]$t_alpha[nrow(act_M)],100)
b_f<-act_M[order(act_M$alpha),]$Fund[1]
dat_b<-dat[dat$Fund==b_f,]
NF<-rep(quantile(dat_b$t_alpha,0.95, na.rm=TRUE),100)
F<-rep(quantile(dat_b$t_alpha,0.05, na.rm=TRUE),100)
n<-paste("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/GRAPHS/PDF/FF_GROSS_ST_10K_top_fund.jpg")
jpeg(n)
plot(density(dat_b$t_alpha, na.rm = TRUE),main="",xlab="",ylab="",lwd=2)
abline(v=a, col='blue', lwd=4, lty=2)
abline(v=NF, col='red',lwd=2,lty=4)
abline(v=F, col='red',lwd=2, lty=4)
legend("topright", legend = c("pdf", "confidence bands", "actual"), col = c("black", "red", "blue"), lty = c(1,2,4), lwd=2, cex=0.7)
t<-paste0("The top fund")
title(main=t , xlab="t_alpha", ylab="density")
dev.off()

################################################################################

#create CDF for agg bootstrap per bootstrap
rm(NF,F,dat1)
act<-act_M
library("purrr")
library(dplyr)
dat1<- dat %>%
  group_by(row) %>%
  summarize(
    percentile = c( 0.05,0.95,0.5),
    value = map_dbl(percentile, ~ quantile(t_alpha, ., na.rm = TRUE))
  )

NF<-dat1[dat1$percentile==0.95,]$value
F<-dat1[dat1$percentile==0.05,]$value

n<-paste("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/GRAPHS/FF_GROSS_ST_BANDS.jpg")
jpeg(n)
plot(ecdf(act$t_alpha),main="",xlab="",ylab="",lty=3,lwd=2,xlim=c(-4,4))
lines(ecdf(NF), col='red',lwd=2)
lines(ecdf(F), col='red',lwd=2)
legend("topleft", legend = c("actual", "confidence bands"), col = c("black", "red"), lty = c(1,4), lwd=2, cex=0.7)
t<-paste0("CDF of t_alpha using gross returns and style benchmark")
title(main=t , xlab="t_alpha", ylab="density")
dev.off()


p1<-dat[dat$row==1000,]$t_alpha
  
n<-paste("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/GRAPHS/FF_GROSS_ST.jpg")
jpeg(n)
plot(ecdf(act$t_alpha),main="",xlab="",ylab="",lwd=2, xlim=c(-4,4))
lines(ecdf(p1), col='red',lwd=2)
legend("topleft", legend = c("actual", "simulated"), col = c("black", "red"), lwd=2, cex=0.7)
t<-paste0("CDF of t_alpha using gross returns and style benchmark")
title(main=t , xlab="t_alpha", ylab="density")
dev.off()









#####################################################################
#Create FF table 3
library(haven)
dat<-read_dta("D:/PhD/Research MG/BS_FF_GROSS_ST_10k.dta")
act_M<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap/FF/ACTUAL/GROSS/ACT_GROSS_ST_1.dta")

#s<-c("LCB","LCG","LCV","MCB","MCG","MCV","SCB","SCG","SCV")


dat3<-matrix(nrow=27,ncol=4)
colnames(dat3)<-c("Pct","Act","Sim","Pct<Act")
dat3[,1]<-c("1","2","3","4","5","10","15","20","25","30","35","40","45","50","55","60","65","70","75","80","85","90","95","96","97","98","99")

library(dplyr)
library(purrr)
v<-act_M %>%
  summarize(
    percentile = c(seq(0.05, 0.95, by = 0.05),0.01, 0.02, 0.03, 0.04, 0.96, 0.97, 0.98, 0.99),
    value = map_dbl(percentile, ~ quantile(t_alpha, ., na.rm = TRUE))
  )
v<-data.frame(v[order(v$value),])

  dat<-dat[!is.na(dat$t_alpha),]
  dat<-dat[dat$R_sqr!=1,]
  

  dat1<- dat %>%
    group_by(r) %>%
    summarize(
      percentile = c(seq(0.05, 0.95, by = 0.05), 0.01, 0.02, 0.03, 0.04, 0.96, 0.97, 0.98, 0.99),
      value = map_dbl(percentile, ~ quantile(t_alpha, ., na.rm = TRUE))
    )
  
  dat1<-data.frame(dat1)
  
 dat3[,2]<-v[,2]
 pct<-c("1","2","3","4","5","10","15","20","25","30","35","40","45","50","55","60","65","70","75","80","85","90","95","96","97","98","99")
for (i in 1:27)
{
  dat3[i,3]<-mean(dat1[dat1$percentile==sort(unique(dat1$percentile))[i],]$value)
}

for (i in 1:27)
{
  dat3[i,4]<-sum(ifelse(dat1[dat1$percentile==sort(unique(dat1$percentile))[i],]$value<v$value[i],1,0))/100
}
  
n<-paste("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/PCT TABLE PER BOOTSTRAP/10k/FF_GROSS_ST.csv")
write.csv(dat3,n)


#############################################################################

#


