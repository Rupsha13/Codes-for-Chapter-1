#KOSOWSKI

dat<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_MK_LCG.dta")

dat2<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_BM_LCG.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=13))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/LCG.dta")
write.csv(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/LCG.csv")

#KOSOWSKI


dat<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_MK_LCV.dta")

dat2<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_BM_LCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=13))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/LCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/LCV.csv")


#KOSOWSKI

dat<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_MK_MCG.dta")

dat2<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_BM_MCG.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=13))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/MCG.dta")
write.csv(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/MCG.csv")


#KOSOWSKI

dat<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_MK_MCV.dta")

dat2<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_BM_MCV.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=13))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,4]<-mean(dat_4f$alpha)
    BS_mat[i,5]<-dat_4f$alpha[order(dat_4f$alpha)][nrow(dat_4f)*0.95]
    BS_mat[i,10]<-mean(dat_4f$t_alpha)
    BS_mat[i,11]<-dat_4f$t_alpha[order(dat_4f$t_alpha)][nrow(dat_4f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/MCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/MCV.csv")


#KOSOWSKI

dat<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_MK_SCG.dta")

dat2<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_BM_SCG.dta")

ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=13))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/SCG.dta")
write.csv(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/SCG.csv")



#KOSOWSKI

dat<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_MK_SCV.dta")

dat2<-read_dta("D:/PhD/Research MG/KOSOWSKI/BS_Gross/BS_1F_BM_SCV.dta")


ux<-unique(dat$Fund)
BS_mat<-data.frame(matrix(nrow=length(ux),ncol=13))
colnames(BS_mat)<-c("Fund","alpha1F_Mean","alpha1F_95","alpha4F_Mean","alpha4F_95","alphaBM_Mean","alphaBM_95","talpha1F_Mean","talpha1F_95","talpha4F_Mean","talpha4F_95","talphaBM_Mean","talphaBM_95")


for(i in 1:length(ux))
{
  dat_1f<-dat[dat$Fund==ux[i],]
  dat_1f<-na.omit(dat_1f)
  
  dat_bm<-dat[dat2$Fund==ux[i],]
  dat_bm<-na.omit(dat_bm)
  
  if(nrow(dat_1f)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-NA
    BS_mat[i,3]<-NA
    BS_mat[i,8]<-NA
    BS_mat[i,9]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,2]<-mean(dat_1f$alpha)
    BS_mat[i,3]<-dat_1f$alpha[order(dat_1f$alpha)][nrow(dat_1f)*0.95]
    BS_mat[i,8]<-mean(dat_1f$t_alpha)
    BS_mat[i,9]<-dat_1f$t_alpha[order(dat_1f$t_alpha)][nrow(dat_1f)*0.95]
  }
  
  
  
  if(nrow(dat_bm)<8)
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-NA
    BS_mat[i,7]<-NA
    BS_mat[i,12]<-NA
    BS_mat[i,13]<-NA
    next
  }
  
  else
  {
    BS_mat[i,1]<-ux[i]
    BS_mat[i,6]<-mean(dat_bm$alpha)
    BS_mat[i,7]<-dat_bm$alpha[order(dat_bm$alpha)][nrow(dat_bm)*0.95]
    BS_mat[i,12]<-mean(dat_bm$t_alpha)
    BS_mat[i,13]<-dat_bm$t_alpha[order(dat_bm$t_alpha)][nrow(dat_bm)*0.95]
  }
}

write_dta(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/SCV.dta")
write.csv(BS_mat,"D:/PhD/Research MG/Math_Example/Q1_DoesItMatter/BS/BS/BS_Table/FAMA/SCV.csv")


