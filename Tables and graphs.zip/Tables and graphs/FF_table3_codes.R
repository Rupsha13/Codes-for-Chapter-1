style<-c("Large Blend_2024-09-08","Large Growth_2024-09-08","Large Value_2024-09-08","Mid Blend_2024-09-08","Mid Growth_2024-09-08","Mid Value_2024-09-08","Small Blend_2024-09-08","Small Growth_2024-09-08","Small Value_2024-09-08")
B<-500
#FF table-3, gross, 4F, BM

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/GROSS/ST BM/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/BS ALPHA/GROSS/ST BM/"

tab_4F_gross_MK<-matrix(nrow=19,ncol=3)
rownames(tab_4F_gross_MK)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
colnames(tab_4F_gross_MK)<-c("Sim","Act","pct_less_act")
pct<-c(c(1,2,3,4,5,10,20,30,40,50,60,70,80,90,95,96,97,98,99))
pct<-pct/100

#second column 'Act'
dat1<-dat
dat<-dat[is.na(dat$t_alpha)==FALSE,]

for (i in 1:length(pct))
{
  tab_4F_gross_MK[i,2]<-round(quantile(ACT_GROSS_MK_1$t_alpha,pct[i]),2)
}


#first column 'sim'
dat<-data.frame(matrix(nrow=0,ncol=0))

for (i in 1:9)
{
  file_name <- paste0(path2, style[i], ".dta")
  dat1<-read_dta(file_name)

  dat<-rbind(dat,dat1)
  rm(dat1)
}

dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]
ux<-unique(dat$Fund)

R<-10000
p<-matrix(nrow=19,ncol=R)
for (i in 1:R)
{
  d<-dat[dat$r==i,]
  # Calculate specific percentiles
  percentiles<- quantile(d$t_alpha, probs = c(1,2,3,4,5,10,20,30,40,50,60,70,80,90,95,96,97,98,99)/100)
  p[,i]<-percentiles
}
tab_4F_gross_MK[,1]<-round(rowMeans(p, na.rm = TRUE),2)

for (i in 1:19)
{
  tab_4F_gross_MK[i,3]<-(sum(tab_4F_gross_MK[i,2]>p[i,])/10000)*100
}
tab_4F_gross_MK<-data.frame(tab_4F_gross_MK)
write_dta(tab_4F_gross_MK,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/PCT TABLE PER FUND/gross_mk.dta")

p<-matrix(nrow=19,ncol=B)
for(b in 1:B)
{
  d<-matrix(nrow=length(ux),ncol=1)
  for (f in 1:length(ux))
  {
    d[f,1]<-dat[dat$Fund==ux[f],]$t_alpha[b]
  } 
  d<-na.omit(d)
  for (i in 1:length(pct))
  {
    p[i,b]<-round(quantile(d,pct[i]),2)
  }
}

tab_4F_gross_BM[,1]<-rowMeans(p)
rm(d,p,dat)

########################################################

#FF table-3, gross, 4F, MK

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/GROSS/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/BS ALPHA/GROSS/"

tab_4F_gross_MK<-matrix(nrow=19,ncol=2)
rownames(tab_4F_gross_MK)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
colnames(tab_4F_gross_MK)<-c("Sim","Act")

#second column 'Act'
dat<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:9)
{
  
  file_name <- paste0(path1, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat<-rbind(dat,dat1)
  rm(dat1)
  
}
dat<-dat[is.na(dat$t_alpha)==FALSE,]

for (i in 1:length(pct))
{
  tab_4F_gross_MK[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
}


#first column 'sim'
dat<-data.frame(matrix(nrow=0,ncol=0))

for (i in 1:9)
{
  file_name <- paste0(path2, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat<-rbind(dat,dat1)
  rm(dat1)
}

dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]
ux<-unique(dat$Fund)

p<-matrix(nrow=19,ncol=B)
for(b in 1:B)
{
  d<-matrix(nrow=length(ux),ncol=1)
  for (f in 1:length(ux))
  {
    d[f,1]<-dat[dat$Fund==ux[f],]$t_alpha[b]
  } 
  d<-na.omit(d)
  for (i in 1:length(pct))
  {
    p[i,b]<-round(quantile(d,pct[i]),2)
  }
}

tab_4F_gross_MK[,1]<-rowMeans(p)
rm(d,p,dat)
############################################################

#FF table-3, net, 4F, BM

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/NET/ST BM/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/BS ALPHA/NET/ST BM/"

tab_4F_net_BM<-matrix(nrow=19,ncol=2)
rownames(tab_4F_net_BM)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
colnames(tab_4F_net_BM)<-c("Sim","Act")
pct<-c(c(1,2,3,4,5,10,20,30,40,50,60,70,80,90,95,96,97,98,99))
pct<-pct/100

#second column 'Act'
dat<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:9)
{
  
  file_name <- paste0(path1, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat<-rbind(dat,dat1)
  rm(dat1)
  
}
dat<-dat[is.na(dat$t_alpha)==FALSE,]

for (i in 1:length(pct))
{
  tab_4F_net_BM[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
}


#first column 'sim'
dat<-data.frame(matrix(nrow=0,ncol=0))

for (i in 1:9)
{
  file_name <- paste0(path2, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat<-rbind(dat,dat1)
  rm(dat1)
}

dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]
ux<-unique(dat$Fund)

p<-matrix(nrow=19,ncol=B)
for(b in 1:B)
{
  d<-matrix(nrow=length(ux),ncol=1)
  for (f in 1:length(ux))
  {
    d[f,1]<-dat[dat$Fund==ux[f],]$t_alpha[b]
  } 
  d<-na.omit(d)
  for (i in 1:length(pct))
  {
    p[i,b]<-round(quantile(d,pct[i]),2)
  }
}

tab_4F_net_BM[,1]<-rowMeans(p)
rm(d,p,dat)

########################################################


#FF table-3, net, 4F, MK

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/NET/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/BS ALPHA/NET/"

tab_4F_net_MK<-matrix(nrow=19,ncol=2)
rownames(tab_4F_net_MK)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
colnames(tab_4F_net_MK)<-c("Sim","Act")

#second column 'Act'
dat<-data.frame(matrix(nrow=0,ncol=0))
for (i in 1:9)
{
  
  file_name <- paste0(path1, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat<-rbind(dat,dat1)
  rm(dat1)
  
}
dat<-dat[is.na(dat$t_alpha)==FALSE,]

for (i in 1:length(pct))
{
  tab_4F_net_MK[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
}


#first column 'sim'
dat<-data.frame(matrix(nrow=0,ncol=0))

for (i in 1:9)
{
  file_name <- paste0(path2, style[i], ".dta")
  dat1<-read_dta(file_name)
  
  dat<-rbind(dat,dat1)
  rm(dat1)
}

dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]
ux<-unique(dat$Fund)

p<-matrix(nrow=19,ncol=B)
for(b in 1:B)
{
  d<-matrix(nrow=length(ux),ncol=1)
  for (f in 1:length(ux))
  {
    d[f,1]<-dat[dat$Fund==ux[f],]$t_alpha[b]
  } 
  d<-na.omit(d)
  for (i in 1:length(pct))
  {
    p[i,b]<-round(quantile(d,pct[i]),2)
  }
}

tab_4F_net_MK[,1]<-rowMeans(p)
rm(d,p,dat)




#######################################################
write.csv(tab_4F_gross_BM,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/tab_4F_gross_BM.csv")
write.csv(tab_4F_gross_MK,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/tab_4F_gross_MK.csv")
write.csv(tab_4F_net_BM,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/tab_4F_net_BM.csv")
write.csv(tab_4F_net_MK,"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/tab_4F_net_MK.csv")
#___________________________________________________________________________________________________
#______________________________________________________________________________________________________

B<-500
style<-c("Large Blend_2024-09-08","Large Growth_2024-09-08","Large Value_2024-09-08","Mid Blend_2024-09-08","Mid Growth_2024-09-08","Mid Value_2024-09-08","Small Blend_2024-09-08","Small Growth_2024-09-08","Small Value_2024-09-08")

#FF table-3, gross, 4F, BM


path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/GROSS/ST BM/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/BS ALPHA/GROSS/ST BM/"

for (s in 1:9)
{

tab_4F_gross_BM<-matrix(nrow=19,ncol=2)
rownames(tab_4F_gross_BM)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
colnames(tab_4F_gross_BM)<-c("Sim","Act")
pct<-c(c(1,2,3,4,5,10,20,30,40,50,60,70,80,90,95,96,97,98,99))
pct<-pct/100

#second column 'Act'

file_name <- paste0(path1, style[s], ".dta")
dat<-read_dta(file_name)
dat<-dat[is.na(dat$t_alpha)==FALSE,]

for (i in 1:length(pct))
{
  tab_4F_gross_BM[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
}


#first column 'sim'
file_name <- paste0(path2, style[s], ".dta")
dat<-read_dta(file_name)

dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]
ux<-unique(dat$Fund)

dat <- dat %>%
  group_by(Fund) %>%
  mutate(row = row_number())

p<-matrix(nrow=19,ncol=B)
for(b in 1:B)
{
  d<-dat[dat$row==b,]$t_alpha
  d<-na.omit(d)
  for (i in 1:length(pct))
  {
    p[i,b]<-round(quantile(d,pct[i]),2)
  }
}

tab_4F_gross_BM[,1]<-rowMeans(p)
rm(d,p,dat)

dynamic_path<-paste0(path1, style[s], ".csv")
write.csv(tab_4F_gross_BM,dynamic_path)

}


########################################################

#FF table-3, gross, 4F, MK

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/GROSS/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/BS ALPHA/GROSS/"

for(s in 1:9)
  
{

tab_4F_gross_MK<-matrix(nrow=19,ncol=2)
rownames(tab_4F_gross_MK)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
colnames(tab_4F_gross_MK)<-c("Sim","Act")

#second column 'Act'
file_name <- paste0(path1, style[s], ".dta")
dat<-read_dta(file_name)
dat<-dat[is.na(dat$t_alpha)==FALSE,]

for (i in 1:length(pct))
{
  tab_4F_gross_MK[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
}


#first column 'sim'
file_name <- paste0(path2, style[s], ".dta")
dat<-read_dta(file_name)

dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]
ux<-unique(dat$Fund)

dat <- dat %>%
  group_by(Fund) %>%
  mutate(row = row_number())

p<-matrix(nrow=19,ncol=B)
for(b in 1:B)
{
  d<-dat[dat$row==b,]$t_alpha
  d<-na.omit(d)
  for (i in 1:length(pct))
  {
    p[i,b]<-round(quantile(d,pct[i]),2)
  }
}

tab_4F_gross_MK[,1]<-rowMeans(p)
rm(d,p,dat)

dynamic_path<-paste0(path1, style[s], ".csv")
write.csv(tab_4F_gross_MK,dynamic_path)

}

############################################################

#FF table-3, net, 4F, BM

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/NET/ST BM/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/BS ALPHA/NET/ST BM/"

for (s in 1: 9)
{

tab_4F_net_BM<-matrix(nrow=19,ncol=2)
rownames(tab_4F_net_BM)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
colnames(tab_4F_net_BM)<-c("Sim","Act")
pct<-c(c(1,2,3,4,5,10,20,30,40,50,60,70,80,90,95,96,97,98,99))
pct<-pct/100

#second column 'Act'
file_name <- paste0(path1, style[s], ".dta")
dat<-read_dta(file_name)
dat<-dat[is.na(dat$t_alpha)==FALSE,]

for (i in 1:length(pct))
{
  tab_4F_net_BM[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
}


#first column 'sim'
file_name <- paste0(path2, style[s], ".dta")
dat<-read_dta(file_name)

dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]
ux<-unique(dat$Fund)

dat <- dat %>%
  group_by(Fund) %>%
  mutate(row = row_number())

p<-matrix(nrow=19,ncol=B)
for(b in 1:B)
{
  d<-dat[dat$row==b,]$t_alpha
  d<-na.omit(d)
  for (i in 1:length(pct))
  {
    p[i,b]<-round(quantile(d,pct[i]),2)
  }
}

tab_4F_net_BM[,1]<-rowMeans(p)
rm(d,p,dat)


dynamic_path<-paste0(path1, style[s], ".csv")
write.csv(tab_4F_net_BM,dynamic_path)

}
########################################################


#FF table-3, net, 4F, MK

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/ACT ALPHA/NET/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/BS/ASSET CLASS/BS ALPHA/NET/"

 for(s in 1:9)
 {
tab_4F_net_MK<-matrix(nrow=19,ncol=2)
rownames(tab_4F_net_MK)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
colnames(tab_4F_net_MK)<-c("Sim","Act")

#second column 'Act'
file_name <- paste0(path1, style[s], ".dta")
dat<-read_dta(file_name)
dat<-dat[is.na(dat$t_alpha)==FALSE,]

for (i in 1:length(pct))
{
  tab_4F_net_MK[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
}


#first column 'sim'
file_name <- paste0(path2, style[s], ".dta")
dat<-read_dta(file_name)

dat<-dat[is.na(dat$t_alpha)==FALSE,]
dat<-dat[dat$R_sqr<1,]
ux<-unique(dat$Fund)

dat <- dat %>%
  group_by(Fund) %>%
  mutate(row = row_number())

p<-matrix(nrow=19,ncol=B)
for(b in 1:B)
{
  d<-dat[dat$row==b,]$t_alpha
  d<-na.omit(d)
  for (i in 1:length(pct))
  {
    p[i,b]<-round(quantile(d,pct[i]),2)
  }
}

tab_4F_net_MK[,1]<-rowMeans(p)
rm(d,p,dat)


dynamic_path<-paste0(path1, style[s], ".csv")
write.csv(tab_4F_net_MK,dynamic_path)

}

#######################################################


#MASON
B<-1000
#FF table-3, net, 4F, BM
style<-c("Large Blend_2024-09-08","Large Growth_2024-09-08","Large Value_2024-09-08","Mid Growth_2024-09-08","Mid Value_2024-09-08","Small Blend_2024-09-08","Small Growth_2024-09-08","Small Value_2024-09-08")
path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/MASON/ACT/ST BM/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/MASON/BS/ST BM/"

for (s in 2:8)
{
  
  tab_4F_net_BM<-matrix(nrow=19,ncol=2)
  rownames(tab_4F_net_BM)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
  colnames(tab_4F_net_BM)<-c("Sim","Act")
  pct<-c(1,2,3,4,5,10,20,30,40,50,60,70,80,90,95,96,97,98,99)
  pct<-pct/100
  
  #second column 'Act'
  file_name <- paste0(path1, style[s], ".dta")
  dat<-read_dta(file_name)
  dat<-dat[is.na(dat$t_alpha)==FALSE,]
  
  for (i in 1:length(pct))
  {
    tab_4F_net_BM[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
  }
  
  
  #first column 'sim'
  file_name <- paste0(path2, style[s], ".dta")
  dat<-read_dta(file_name)
  
  dat<-dat[is.na(dat$t_alpha)==FALSE,]
  dat<-dat[dat$R_sqr<1,]
  ux<-unique(dat$Fund)
  
  dat <- dat %>%
    group_by(Fund) %>%
    mutate(row = row_number())
  
  p<-matrix(nrow=19,ncol=B)
  for(b in 1:B)
  {
    d<-dat[dat$row==b,]$t_alpha
    d<-na.omit(d)
    for (i in 1:length(pct))
    {
      p[i,b]<-round(quantile(d,pct[i]),2)
    }
  }
  
  tab_4F_net_BM[,1]<-rowMeans(p)
  rm(d,p,dat)
  
  dynamic_path<-paste0(path1, style[s], ".csv")
  write.csv(tab_4F_net_BM,dynamic_path)
  
}
########################################################


#FF table-3, net, 4F, MK

path1 <- "C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/MASON/ACT/"
path2<-"C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap 8-21/MASON/BS/"

for(s in 2:8)
{
  tab_4F_net_MK<-matrix(nrow=19,ncol=2)
  rownames(tab_4F_net_MK)<-c("1","2","3","4","5","10","20","30","40","50","60","70","80","90","95","96","97","98","99")
  colnames(tab_4F_net_MK)<-c("Sim","Act")
  
  #second column 'Act'
  file_name <- paste0(path1, style[s], ".dta")
  dat<-read_dta(file_name)
  dat<-dat[is.na(dat$t_alpha)==FALSE,]
  
  for (i in 1:length(pct))
  {
    tab_4F_net_MK[i,2]<-round(quantile(dat$t_alpha,pct[i]),2)
  }
  
  
  #first column 'sim'
  file_name <- paste0(path2, style[s], ".dta")
  dat<-read_dta(file_name)
  
  
  dat <- dat %>%
    group_by(Fund) %>%
    mutate(row= row_number())
  
  dat<-dat[is.na(dat$t_alpha)==FALSE,]
  dat<-dat[dat$R_sqr<1,]
  ux<-unique(dat$Fund)
  
 
  p<-matrix(nrow=19,ncol=B)
  for(b in 1:B)
  {
    d<-dat[dat$row==b,]$t_alpha
    d<-na.omit(d)
    for (i in 1:length(pct))
    {
      p[i,b]<-round(quantile(d,pct[i]),2)
    }
  }
  
  tab_4F_net_MK[,1]<-rowMeans(p)
  rm(d,p,dat)
  
  dynamic_path<-paste0(path1, style[s], ".csv")
  write.csv(tab_4F_net_MK,dynamic_path)
  
}

#######################################################










