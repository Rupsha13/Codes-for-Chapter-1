library(haven)
dat<-read_dta("D:/PhD/Research MG/BS_FF_NET_MK_10k.dta")
act_M<-read_dta("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/FF Bootstrap/FF/ACTUAL/NET/ACT_NET_MK.dta")

library(dplyr)

df <- dat %>%
  select(Fund,style) %>%
  distinct()

act_M<-merge(act_M,df, by="Fund")

mat<-data.frame(matrix(nrow=nrow(act_M),ncol=7))
colnames(mat)<-c("Fund","act_t_alpha","pct_5","pct_95","skill","neg_skill","style")
mat[,1]<-act_M$Fund
mat[,2]<-act_M$t_alpha
mat[,7]<-act_M$style

dat<-dat[!is.na(dat$t_alpha),]
dat<-dat[dat$R_sqr!=1,]

for (i in 1:4794)
{
  mat[i,3]<-quantile(dat[dat$Fund==act_M$Fund[i] & dat$style==act_M$style[i],]$t_alpha,0.05)
  mat[i,4]<-quantile(dat[dat$Fund==act_M$Fund[i] & dat$style==act_M$style[i],]$t_alpha,0.95)
}

mat$skill<-ifelse(mat$act_t_alpha>mat$pct_95,1,0)
mat$neg_skill<-ifelse(mat$act_t_alpha<mat$pct_5,1,0)

n<-paste("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/RESULTS/PCT TABLE PER FUND/10k/FF_NET_MK.csv")
write.csv(mat,n)














mk<-HL_NET_MK
st<-HL_NET_ST

plot(ecdf(mk$alpha))
lines(ecdf(st$alpha),col='red', lwd=3)

summary(mk$alpha)
summary(st$alpha)

mk<-mk[mk$skill==1,]
st<-st[st$skill==1,]

mk<-merge(mk,a1_tna, by="Fund")

library(dplyr)
mk1<-mk %>%
  group_by(Fund) %>%
  select(alpha,tna,caldt)
mk1<-mk1[order(mk1$Fund),]
mk1$va<-mk1$alpha*mk1$tna*100

mk2<- mk1 %>%
  group_by(Fund) %>%
  summarize(tot_va=sum(va))








