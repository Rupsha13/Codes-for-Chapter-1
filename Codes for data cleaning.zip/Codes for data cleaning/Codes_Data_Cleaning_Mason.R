dat1<-read_dta("D:/PhD/Research MG/STYLE/MASON 2015/Ms_Ret_3.dta")
ux<-unique(dat$fundid)
dat$m1<-""
dat<-dat[!is.na(dat$net_ret),]

for(i in 1:length(ux))
{
  d<-dat[dat$fundid==ux[i],]$date[1]
  r<-dat[dat$fundid==ux[i],]$net_ret[1]
  
  for(j in (i+1):length(ux))
  {
    if(dat[dat$fundid==ux[j],]$date[1]==d)
    {
      if(dat[dat$fundid==ux[j],]$net_ret[1]==r)
      {
        dat[dat$fundid==ux[j],]$m1[1]<-ux[i]
      }
    }
    else
    {
      next
    }
  }
}

dat1<-dat[dat$m1!="",]
write_dta(dat1,"D:/PhD/Research MG/STYLE/MASON 2015/Same_Ret.dta")

dat<-read_dta("D:/PhD/Research MG/STYLE/MASON 2015/Same_Ret.dta")
ux<-unique(dat$fundid)
ux1<-unique(dat$m1)
mat<-data.frame(nrow=65,ncol=2)
colnames(mat)<-c("fund","matching_fund")

for (i in 1:length(ux))
{
  dat_a<-dat1[dat1$fundid==ux[i],]
  dat_b<-dat1[dat1$fundid==ux1[i],]
  
  if(nrow(dat_a)==nrow(dat_b))
  {
  
  if(sum(ifelse(dat_a$date==dat_b$date,1,0))==nrow(dat_a))
  {
    if(sum(ifelse(dat_a$net_ret==dat_b$net_ret,1,0))==nrow(dat_a))
    {
      mat[i,1]<-ux[i]
      mat[i,2]<-ux1[i]
    }
    else
    {
      mat[i,1]<-ux[i]
      mat[i,2]<-NA
    }
  }
  else
  {
    mat[i,1]<-ux[i]
    mat[i,2]<-NA
  }
  }
  else
{
  mat[i,1]<-ux[i]
  mat[i,2]<-NA
}
}
mat<-na.omit(mat)
write_dta(mat,"D:/PhD/Research MG/STYLE/MASON 2015/Same_Ret.dta")
