dat<-crsp_a_m_84_06_pos

#replacing na in fund names by checking fund numbers
for (i in 1:nrow(dat))
{
  if(is.na(dat$fundname[i])==TRUE)
  {
    dat$fundname[i]<-ifelse(dat$crsp_fundno[i]==dat$crsp_fundno[i-1],dat$fundname[i-1],NA)
  }
}

#create a dummy a to identify same fund with different share class
dat<-no_na_fundname
dat<-dat[order(dat$fname),]

a<-matrix(nrow=nrow(dat),ncol=1)
f_name<-dat$fname[1]
a[1]<-1

for (i in 2:nrow(dat))
{
  if(f_name==dat$fname[i])
  {
    a[i]<-a[i-1]
  }
  else
  {
    a[i]<-a[i-1]+1
  }
  f_name<-dat$fname[i]
}
dat<-data.frame(dat,a)

#create a second dummy a1 for funds that might have changed their names over time but actually
#have the same fund no hence same fund

dat<-table
a1<-matrix(nrow=nrow(dat),ncol=1)
a1[1]<-dat$a[1]
fundno<-dat$crsp_fundno[1]

for (j in 2:nrow(dat))
{
  if(fundno==dat$crsp_fundno[j])
  {
    a1[j]<-a1[j-1]
  }
  else
  {
    a1[j]<-dat$a[j]
  }
  fundno<-dat$crsp_fundno[j]
}

length(unique(a1))
#5645 (for CRSP 1984-2006)
dat<-data.frame(dat,a1)

write.csv(dat,"C:/Users/Administrator/Desktop/My research/REPLICATING FAMA 2010/table.csv")

###########################################
#check number of NA in expense ratio
dat<-final_5600_funds
dat<-no_na_tna
sum(is.na(dat$expenseratioasoffiscalyearend)==TRUE)
dat2<-dat[is.na(dat$expenseratioasoffiscalyearend)==TRUE,]
ux_na<-unique(dat2$a1)
dat3<-dat[is.na(dat$expenseratioasoffiscalyearend)==FALSE,]
ux_not_na<-unique(dat3$a1)
same<-intersect(ux_na,ux_not_na)

###########################################
#remove NA from expense ratio by filling it with the same fund's previous month

dat<-final.5600.funds

for (i in 2:nrow(dat))
{
  if (is.na(dat$expenseratioasoffiscalyearend[i])==TRUE)
  {
    if(dat$a1[i]==dat$a1[i-1])
    {
    dat$expenseratioasoffiscalyearend[i]<-dat$expenseratioasoffiscalyearend[i-1]
    }
  }
}

#remove NA if the fund number appears first has missing exp ratio
#first make a matrix of exp ratio with the fund num (a1)
exp_ratio<-matrix(nrow=240,ncol=2)
for (i in 1:length(same))
{
  for (j in 1:nrow(dat))
  {
    if (dat$a1[j]==same[i])
    {
      if(is.na(dat$expenseratioasoffiscalyearend[j])==FALSE)
      {
        exp_ratio[i,1]<-same[i]
        exp_ratio[i,2]<-dat$expenseratioasoffiscalyearend[j]
      }
    }
  }
}
for(i in 1:nrow(exp_ratio))
{
  for (j in 1:nrow(dat))
  {
    if(dat$a1[j]==exp_ratio[i,1])
    {
      if(is.na(dat$expenseratioasoffiscalyearend[j])==TRUE)
      {
        dat$expenseratioasoffiscalyearend[j]<-exp_ratio[i,2]
      }
    }
  }
}

write.csv(dat,"C:/Users/HP/Desktop/PhD/Research_MG/Replicating Fama/Final File/Dealing with share class (merged using fundno, year)/table.csv")



#######################################################################################
#There are some missing TNA in main file which I need to match for expxense ratios
#I try to figure out how many missing TNA I have

dat<-table
a<-0

for (i in 1:nrow(dat))
{
  if(is.na(dat$mtna[i])==TRUE)
  {
    a<-a+1

  }
}
#I have 35170 missing TNA dat3 table has the list
#I will fill up the TNA by the same fund's previous caldt's TNA in the main file (dat)
a<-0
for (i in 2:nrow(dat))
{
  if (is.na(dat$mtna[i])==TRUE)
  {
    
    if (dat$a1[i-1]==dat$a1[i])
    {
      a<-a+1
      dat$mtna[i]<-dat$mtna[i-1]
    }
  }
}

#Now I still have 3807 missing TNA for the funds that appear first with missing TNA
#So I need to fill it in with the same fund's next year TNA
#First I export the dat (main table) into excel ans sort the date descending order(new to old)
write.csv(dat,"C:/Users/HP/Desktop/PhD/Research_MG/Replicating Fama/Final File/Dealing with share class (merged using fundno, year)/table.csv") 
#Import agian
#check if there are 3807 missing TNA
#Now fill in the missing TNA with same fund's next closest caldt's TNA (since the data is re ordered I can run the previous code)
#previous code
a<-0
for (i in 2:nrow(dat))
{
  if (is.na(dat$mtna[i])==TRUE)
  {
    
    if (dat$a1[i-1]==dat$a1[i])
    {
      a<-a+1
      dat$mtna[i]<-dat$mtna[i-1]
    }
  }
}

#I still have 24 missing TNA, I will inspect them manually
#Let's create a matrix
a<-0
dat3<-matrix(nrow=24,ncol=4)
for (i in 1:nrow(dat))
{
  if(is.na(dat$mtna[i])==TRUE)
  {
    a<-a+1
    dat3[a,1]<-dat$a1[i]
    dat3[a,2]<-dat$caldt[i]
    dat3[a,3]<-dat$mtna[i]
    dat3[a,4]<-i
    
  }
}
#after creating the matrix let's export the dat that has 24 TNA
write.csv(dat,"C:/Users/HP/Desktop/PhD/Research_MG/Replicating Fama/Final File/Dealing with share class (merged using fundno, year)/table.csv") 
#There are 3 funds with missing TNA, dat3 has rhe list. Two of them does not have missing expense ratio
#So I will replace the NA TNA with 999999, so that while filling out missing expense rario I dont encounter any problem
#one fund ahve both missing TNA ande xpense ratio, that fund just have one observation in the dataset so I decide to drop it
#Also similar approach taken by Pollet and Wilson 2007 (i still keep it will ask Michael)



##################################################################################
#There are some missing caldt in main file which I need to match for expxense ratios
#I try to fighure out how many missing caldt I have
a<-0
dat2<-data.frame(nrow=0,ncol=6)
for (i in 1:nrow(dat))
{
  if(is.na(dat$caldt[i])==TRUE)
  {
    a<-a+1
    #make a matrix with all the missing caldt
    dat2[a,1]<-dat$a1[i]
    dat2[a,2]<-dat$year[i]
    dat2[a,3]<-dat$caldt[i]
    dat2[a,4]<-dat$mtna[i]
    dat2[a,5]<-dat$mret[i]
    dat2[a,6]<-i
    
  }
}
#I just have 8 observation in my data that has missing caldt 
#I will try to fill it manually by checking the excel file now that I know the a1, year, the row number
#Check the table dat2 and fill in the missing caldt in the excel file (table) then import again
#importing again
dat<-table
##########################################################################################
#Fill missing expense ratio with funds that have similar TNA
#First I create a matrix with fund num (a1), year, TNA, caldt
#ux_na has all the funds that have missing expense ratio
#create a matrix to keep the values

fund_na<-data.frame(matrix(nrow=0,ncol=5))
a<-0
for (i in 1:length(ux_na))
{
  for (j in 1:nrow(dat))
  {
    if (ux_na[i]==dat$a1[j])
    {
      a<-a+1
      fund_na[a,1]<-dat$a1[j]
      fund_na[a,2]<-dat$year[j]
      fund_na[a,3]<-dat$caldt[j]
      fund_na[a,4]<-dat$mtna[j]
      fund_na[a,5]<-dat$shareclass[j]
      
    }
  }
}
                   
colnames(fund_na)<- c("a1", "Year", "caldt", "mtna", "exp ratio", "share class")
write.csv(fund_na,"C:/Users/HP/Desktop/PhD/Research_MG/Replicating Fama/Final File/Dealing with missing expense ratio/fund_na_exp.csv")

#next I match the TNA of each fund num (a1) of funds that has missing exp ratio (using 
#dataset fund_na), with the entire dataset (main file, table).Whichever fund has the least 
#different tna I put the exp-ratio of that fund in place of missing value. Note: I search for each
#year separately.

#TNA is monthly data but expense ratio is annual
#I plan to match last available month's data of that year (where the exp ratio is missing)
#so export the fund_na then sort caldt old to new then import back
#1.take one fund last caldt, create a matrix (check) with all the similar caldt in dataset dat, calculate
#diff in exp ratio whichever diff in exp ratio is minimum I use that fund's expense ratio

#the process
#1.from ux_na take one fund
#2.from fund_na_exp see how many years of missing exp ratio
#3.run loop for each year take the last available caldt
#4.match the caldt in the main file, take the diff in mtna
#5.min diff in tna, use that fund's exp ratio
#6.if there are more than one min tna (the diff is same for multiple funds) then create a separate matrix


#6.a.first, I create matrix for only one min tna
dat<-no_na_tna
#lets see the unique fund a1
ux_na<-unique(fund_na_exp$a1)
#create a matrix to store the a1 and exp to replace with
final_mat<-data.frame(matrix(nrow=0,ncol=8))
colnames(final_mat)<-c("a1_to_replace", "mtna_to_check", "a1_to_replace_with", "mtna_checked", "caldt", "exp_ratio", "share class", "share class to replace with")

#run a loop for each one
for (f in 1:length(ux_na))
{
  #run loop to see how many years of missing exp ratio
  years<-data.frame(matrix(nrow=0,ncol=1))
  colnames(years)<-c("years")
  check_year<-0000 #take an arbitrary year to compare
  for (y in 1:nrow(fund_na_exp))
  {
    if(ux_na[f]==fund_na_exp$a1[y] & fund_na_exp$Year[y]!=check_year)
    {
     years[nrow(years)+1,1]<-fund_na_exp$Year[y]
     check_year<-fund_na_exp$Year[y]
    }
  }
  #in years I have all the years for one fund
  #run loop for y=each year to get the last available caldt
  for (y in 1:nrow(years))
  {
    #choose the last available month(appears last for each year)
    check_year<-years[y,1]
    check_a1<-ux_na[f]
    for (i in 1:nrow(fund_na_exp))
    {
      if (fund_na_exp$a1[i]==check_a1 & check_year==fund_na_exp$Year[i])
      {
        if(fund_na_exp$Year[i]!=fund_na_exp$Year[i+1])
        {
          
          check_caldt<-fund_na_exp$caldt[i]
          check_mtna<-fund_na_exp$mtna[i]
          check_shareclass<-fund_na_exp$`share class`[i]
        }
      }
      
    }
    #in check_caldt I have the last available month of one year of one fund
    #match the check_caldt with all the funds' (except check_a1) caldt in the main data (dat)
    #if matches find the diff in the tna (check_mtna and tna from the fund in dat)
    #store in a matrix with the fund num (a1) then choose the min of all tna in the matrix
    check_tna_a1<-data.frame(matrix(nrow=0,ncol=5))
    a<-0
    
    for(j in 1:nrow(dat))
    {
      if (dat$a1[j]!=check_a1 & dat$caldt[j]==check_caldt)
      {
        a<-a+1
        check_tna_a1[a,1]<-dat$a1[j]
        check_tna_a1[a,2]<-abs(check_mtna-dat$mtna[j])
        check_tna_a1[a,3]<-dat$mtna[j]
        check_tna_a1[a,4]<-dat$expenseratioasoffiscalyearend[j]
        check_tna_a1[a,5]<-dat$shareclass[j]
        
        
       
      }
    }
    
    colnames(check_tna_a1)<-c("a1","diff_mtna", "mtna", "exp_ratio", "share_class")
    #find the minimum of diff
    min_tna<-min(check_tna_a1$diff_mtna)
    count_min_tna<-0
    #count how many min tna
    for(m in 1:nrow(check_tna_a1))
    {
      if(check_tna_a1$diff_mtna[m]==min_tna)
      {
        count_min_tna<-count_min_tna+1
        
      }
    }
    if (count_min_tna==1)
    { 
      
      #search for min_tna 
      for(s in 1:nrow(check_tna_a1))
      {
        if(check_tna_a1$diff_mtna[s]==min_tna)
        {
          a1_to_replace<-check_tna_a1$a1[s]
          tna_to_replace<-check_tna_a1$mtna[s]
          exp_to_replace<-check_tna_a1$exp_ratio[s]
          share_class_to_replace<-check_tna_a1$share_class[s]
        }
      }
      final_mat[nrow(final_mat)+1,1]<-check_a1
      final_mat[nrow(final_mat),2]<-check_mtna
      final_mat[nrow(final_mat),3]<-a1_to_replace
      final_mat[nrow(final_mat),4]<-tna_to_replace
      final_mat[nrow(final_mat),5]<-check_caldt
      final_mat[nrow(final_mat),6]<-exp_to_replace
      final_mat[nrow(final_mat),7]<-check_shareclass
      final_mat[nrow(final_mat),8]<-share_class_to_replace
    }
    

  }
}

write.csv(final_mat,"C:/Users/HP/Desktop/PhD/Research_MG/Replicating Fama/Final File/Dealing with missing expense ratio/table1.csv")

fund_na_exp<-fund_na
#6.b. I create matrix for more than one min tna
dat<-no_na_tna
#lets see the unique fund a1
ux_na<-unique(fund_na_exp$a1)
#create a matrix to store the a1 and exp to replace with
final_mat<-data.frame(matrix(nrow=0,ncol=8))
colnames(final_mat)<-c("a1_to_replace", "mtna_to_check", "a1_to_replace_with", "mtna_checked", "caldt", "exp_ratio","share class", "share class to replace with")

#run a loop for each one
for (f in 1:length(ux_na))
{
  #run loop to see how many years of missing exp ratio
  years<-data.frame(matrix(nrow=0,ncol=1))
  colnames(years)<-c("years")
  check_year<-0000 #take an arbitrary year to compare
  for (y in 1:nrow(fund_na_exp))
  {
    if(ux_na[f]==fund_na_exp$a1[y] & fund_na_exp$Year[y]!=check_year)
    {
      years[nrow(years)+1,1]<-fund_na_exp$Year[y]
      check_year<-fund_na_exp$Year[y]
    }
  }
  #in years I have all the years for one fund
  #run loop for y=each year to get the last avaiable caldt
  for (y in 1:nrow(years))
  {
    #choose the last available month(appears last for each year)
    check_year<-years[y,1]
    check_a1<-ux_na[f]
    for (i in 1:nrow(fund_na_exp))
    {
      if (fund_na_exp$a1[i]==check_a1 & check_year==fund_na_exp$Year[i])
      {
        if(fund_na_exp$Year[i]!=fund_na_exp$Year[i+1])
        {
          
          check_caldt<-fund_na_exp$caldt[i]
          check_mtna<-fund_na_exp$mtna[i]
          check_shareclass<-fund_na_exp$`share class`[i]
        }
      }
      
    }
    #in check_caldt I have the last available month of one year of one fund
    #match the check_caldt with all the funds' (except check_a1) caldt in the main data (dat)
    #if matches find the diff in the tna (check_mtna and tna from the fund in dat)
    #store in a matrix with the fund num (a1) then choose the min of all tna in the matrix
    check_tna_a1<-data.frame(matrix(nrow=0,ncol=5))
    a<-0
    
    for(j in 1:nrow(dat))
    {
      if (dat$a1[j]!=check_a1 & dat$caldt[j]==check_caldt)
      {
        a<-a+1
        check_tna_a1[a,1]<-dat$a1[j]
        check_tna_a1[a,2]<-abs(check_mtna-dat$mtna[j])
        check_tna_a1[a,3]<-dat$mtna[j]
        check_tna_a1[a,4]<-dat$expenseratioasoffiscalyearend[j]
        check_tna_a1[a,5]<-dat$shareclass[j]
        
      }
    }
    
    colnames(check_tna_a1)<-c("a1","diff_mtna", "mtna", "exp_ratio", "share_class")
    #find the minimum of diff
    min_tna<-min(check_tna_a1$diff_mtna)
    count_min_tna<-0
    row_num<-data.frame(matrix(nrow=0,ncol=1))
    #count how many min tna
    for(m in 1:nrow(check_tna_a1))
    {
      if(check_tna_a1$diff_mtna[m]==min_tna)
      {
        count_min_tna<-count_min_tna+1
        row_num[count_min_tna,1]<-m
      }
    }
    if (count_min_tna!=1)
    { 
      
      for (t in 1:count_min_tna)
      {
          
          final_mat[nrow(final_mat)+1,1]<-check_a1
          final_mat[nrow(final_mat),2]<-check_mtna
          final_mat[nrow(final_mat),3]<-check_tna_a1$a1[row_num[t,1]]
          final_mat[nrow(final_mat),4]<-check_tna_a1$mtna[row_num[t,1]]
          final_mat[nrow(final_mat),5]<-check_caldt
          final_mat[nrow(final_mat),6]<-check_tna_a1$exp_ratio[row_num[t,1]]
          final_mat[nrow(final_mat),7]<-check_shareclass
          final_mat[nrow(final_mat),8]<-check_tna_a1$share_class[row_num[t,1]]
        }
      }
  }
  }

length(unique(final_mat$a1_to_replace))
write.csv(final_mat,"C:/Users/HP/Desktop/PhD/Research_MG/Replicating Fama/Final File/Dealing with missing expense ratio/table2.csv")

#NOTE:
#Let's fill the missing exp ratio for one min tna in the main file dat
#Now the two matrix I created for missing exp ratios:min 1 min tna, greater than 1 min tna
#while matching the tna, some funds may have matched with tna of funds (except itself) that have missing exp ratio too
#so, it appears NA in exp ratio to be replaced with under those funds 
#There are 8 missing exp ratio observation in one min tna file
#531 missing observation in greater than one min tna file
#so, i have to run the entire process couple of times to fill up all the missing exp ratio in the main file
#I will match a1 from 1 min tna file with main file and replace the exp ratio present in one min tna file
#in this process 8 funds will be replaced by NA again
#to fill in those again, I will run the entire process again from the begining
#######################################################################################

#filling missing exp ratio from one min tna file to main file

dat_check<-table_MISSING_EXP_1MINTNA
check_check<-data.frame(matrix(nrow=0,ncol=1))#to check which ones are nor getting replaced
a<-0#to see how many got replaced
for( j in 1:nrow(dat_check))
{
  check_a1<-dat_check$a1_to_replace[j]
  check_caldt<-dat_check$caldt[j]
  for (i in 1:nrow(dat))
{
  if(check_a1==dat$a1[i] & check_caldt==dat$caldt[i] &is.na(dat$expenseratioasoffiscalyearend[i]==TRUE))
  {
    dat$expenseratioasoffiscalyearend[i]<-dat_check$exp_ratio[j]
    a<-a+1
    check_check[a,]<-dat_check$a1_to_replace[j]
    
  }

}
}

#After fill in the missing exp ratio for only one caldt (the last avaiable) I need to fill in for rest of the caldt 
#of that year
#remove NA from expense ratio by filling it with the same fund's previous month



for (i in 2:nrow(dat))
{
  if (is.na(dat$expenseratioasoffiscalyearend[i])==TRUE)
  {
    if(dat$a1[i]==dat$a1[i-1])
    {
      dat$expenseratioasoffiscalyearend[i]<-dat$expenseratioasoffiscalyearend[i-1]
    }
  }
}

#just to check if all the a1 in 1 min tna has exp ratio filled (except 8) in the main dat
a<-0
for (i in 1:nrow(dat_check))
{
  for (j in 1:length(ux_na))
  {
    if(dat_check$a1_to_replace[i]==ux_na[j])
    {
      a<-a+1
    }
  }
}

########################################################################################
#adding the 4 factors in the main file 
dat<-no_na_tna
dat1<-X4_FACTOR

#I craete a column exactly like the date column in 4 factor dataset
month<-matrix(nrow=nrow(dat),ncol=1)
date_new<-matrix(nrow=nrow(dat),ncol=1)
colnames(date_new)<-c("date_new")
a<-0
for (i in 1:nrow(dat))
{
  month[i]<-substring(dat$caldt[i],1,unlist(gregexpr('/', dat$caldt[i]))[1]-1)
  if(nchar(month[i])==1)
  {
    a<-a+1
    date_new[i]<-paste0(dat$year[i],0,month[i])
  }
  else
  {
    date_new[i]<-paste0(dat$year[i],month[i])
    }
  
}
dat<-data.frame(dat,date_new)


#I will just match the date in both dataset and put the 4 factors
mktrf<-matrix(nrow=nrow(dat),ncol=1)
colnames(mktrf)<-c("mktrf")

smb<-matrix(nrow=nrow(dat),ncol=1)
colnames(smb)<-c("smb")

hml<-matrix(nrow=nrow(dat),ncol=1)
colnames(hml)<-c("hml")

mom<-matrix(nrow=nrow(dat),ncol=1)
colnames(mom)<-c("mom")

rf<-matrix(nrow=nrow(dat),ncol=1)
colnames(rf)<-c("rf")

for (i in 1:nrow(dat))
{
  for (j in 1:nrow(dat1))
  {
    if(dat$date_new[i]==dat1$date[j])
    {
      mktrf[i]<-dat1$mktrf[j]
      smb[i]<-dat1$smb[j]
      hml[i]<-dat1$hml[j]
      mom[i]<-dat1$mom[j]
      rf[i]<-dat1$rf[j]
    }
  }
}

dat<-data.frame(dat,mktrf,smb,hml,mom,rf)
write.csv(dat,"C:/Users/HP/Desktop/PhD/Research_MG/Replicating Fama/Final File/Dealing with missing expense ratio/Final_file (with missing exp).csv")
################################################################################################################


#Let's check how many missing expense ratios we have
dat<-`Final_file.(with.missing.exp)`
f_num<-data.frame(matrix(nrow=0,ncol=1))
for (i in 1:nrow(dat))
{
  if (is.na(dat$expenseratioasoffiscalyearend[i])==TRUE)
  {
    f_num[nrow(f_num)+1,1]<-dat$a1[i]
  }
}
ux<-unique(f_num)
dat1<-table_MISSING_EXP_1MINTNA
ux1<-unique(dat1$a1_to_replace)

dat2<-table_MISSING_EXP_greaterthan1MINTNA
ux2<-unique(dat2$a1_to_replace)

#here I fill in missing expense ratio from table missing exp_1 min tna
#i use break to make the process faster, that is i fill only 1 a1 out of many (same a1 differnt dates)
#next i will run a loop to fill up the other dates too
for (i in 1:length(ux1))
{
  for (j in 1:nrow(dat))
  {
    if(dat$a1[j]==ux1[i])
    {
      dat$expenseratioasoffiscalyearend[j]<-dat1$exp_ratio[i]
      break
    }
  }
}

for (i in 1:nrow(dat))
{
  if(is.na(dat$expenseratioasoffiscalyearend[i])==TRUE)
  {
    if(dat$a1[i]==dat$a1[i-1])
    {
      dat$expenseratioasoffiscalyearend[i]<-dat$expenseratioasoffiscalyearend[i-1]
    }
  }
}

###############################################################################################

#Fama drops fund that are not at least 5 years old, so drop funds born on or after 2002

dat<-`final.file.(missing.exp).no.fund.less.than.8.months`
dummy<-matrix(nrow=nrow(dat),ncol=1)


dat_new<-data.frame(dat,dummy)
dat_new$dummy[1]<-0
for (i in 2:nrow(dat))
{
  if(dat$a1[i]==dat$a1[i-1])
  {
    next
  }
  
  if(dat$year[i]>=2002)
  {
    dat_new$dummy[i]<-1
  }
}

dat_new$dummy[4176]

for (i in 1:nrow(dat_new))
{
  if(is.na(dat_new$dummy[i])==TRUE)
  {
    dat_new$dummy[i]<-dat_new$dummy[i-1]
  }
}
write.csv(dat,"C:/Users/HP/Desktop/PhD/Research_MG/Replicating Fama/Final File/Dealing with missing expense ratio/Final_file (with missing exp) removed less than 8 months, less than 5 year old.csv")
#################################################################################################################
dat<-`Final_file.(with.missing.exp).removed.less.than.8.months,.less.than.5.year.old`

install.packages("plm")
library(plm)

ret<-dat$mret-dat$rf  
reg<-plm(ret~dat$mktrf+dat$smb+dat$hml+dat$mom, data=dat, index = c("a1","caldt", model="within"))
is.pbalanced(dat)

datp<-pdata.frame(dat,index="a1")
reg<-plm(ret~mktrf+smb+hml+mom, data=datp, model="within")
summary(reg)

alpha<-fixef(reg)
p<-0
n<-0

coefficients(reg)

for (i in 1:length(alpha))
{
  if (alpha[i]>0)
  {
  p<-p+1
  }
  else
  {
    n<-n+1
  }
}

