dat<-Ret_tna
dat1<-dat[is.na(dat$Style)==FALSE,]


lcg<-dat1[dat1$Style==3,]
write.csv(lcg,"D:/PhD/Reserach MG/Morningstar Direct/STOCKS/Style/lcg.csv")
lcv<-dat[dat$`Equity Style Box (Long)`==1,]
write.csv(lcg,"D:/PhD/Reserach MG/Morningstar Direct/STOCKS/Style/lcv.csv")
mcg<-dat[dat$`Equity Style Box (Long)`==6,]
write.csv(mcg,"D:/PhD/Reserach MG/Morningstar Direct/STOCKS/Style/mcg.csv")
mcv<-dat[dat$`Equity Style Box (Long)`==4,]
write.csv(mcv,"D:/PhD/Reserach MG/Morningstar Direct/STOCKS/Style/mcv.csv")
scg<-dat[dat$`Equity Style Box (Long)`==9,]
write.csv(scg,"D:/PhD/Reserach MG/Morningstar Direct/STOCKS/Style/scg.csv")
scv<-dat[dat$`Equity Style Box (Long)`==7,]
write.csv(scv,"D:/PhD/Reserach MG/Morningstar Direct/STOCKS/Style/scv.csv")


dat1<-monthly_return_95_23
lcg<-merge(lcg,dat1)
write.csv(lcg1,"D:/PhD/Reserach MG/Skewness/lcg1.csv")
lcv<-merge(lcv,dat1)
write.csv(lcv1,"D:/PhD/Reserach MG/Skewness/lcv1.csv")
mcg<-merge(mcg,dat1)
write.csv(mcg1,"D:/PhD/Reserach MG/Skewness/mcg_final.csv")
mcv<-merge(mcv,dat1)
write.csv(mcv1,"D:/PhD/Reserach MG/Skewness/mcv_final.csv")
scg<-merge(scg,dat1)
write.csv(scg1,"D:/PhD/Reserach MG/Skewness/scg_final.csv")
scv<-merge(scv,dat1)
write.csv(scv1,"D:/PhD/Reserach MG/Skewness/scv_final.csv")

install.packages("reshape2")
library(reshape2)


lcg1<-melt(lcg,id.vars = c("Id","Name","Ticker","SecId","FundId","PerformanceId","Style","Style_Name"))
lcv1<-melt(lcv,id.vars = c("Id","Name","Ticker","SecId"))
mcg1<-melt(mcg,id.vars = c("Id","Name","Ticker","SecId"))
mcv1<-melt(mcv,id.vars = c("Id","Name","Ticker","SecId"))
scg1<-melt(scg,id.vars = c("Id","Name","Ticker","SecId"))
scv1<-melt(scv,id.vars = c("Id","Name","Ticker","SecId"))

lcg1<-rename(lcg1,Date=Net_Date)
lcg1$Date<-as.Date(substr(lcg1$variable,16,25))
lcg1<-lcg1[,-9]


stocks_full<-rbind(lcg_final,lcv_final,mcg_final,mcv_final,scg_final,scv_final)

summary(stocks_full)

quantile(na.omit(lcg_final)$Return,probs = seq(0.1,1, by=0.1))

length(unique(stocks_full$SecId))



dat<-read.csv("D:/PhD/Research MG/Data/Morningstar Direct/Stocks/Return/monthly_return_95-23.csv")
style<-dat[is.na(dat$`Equity Style Box (Long)_x`)==TRUE,]
ux1<-unique(style$FundId_x)
dat1<-dat[is.na(dat$`Equity Style Box (Long)_x`)==FALSE,]
ux2<-unique(dat1$FundId_x)
length(intersect(ux1,ux2))

dat<-FULL_2
dat_new<-melt(dat,id.vars = c("id","name","ticker","secid","inceptiondate","delistingdate"))
dat_new<-rename(dat_new,Return=value)
length(unique(dat$secid))
dat_new$Year<-as.numeric(substr(dat_new$variable,16,19))
dat_new$Month<-as.numeric(substr(dat_new$variable,21,22))
dat_new<-dat_new[,-5]
dat_new$month<-format (as.Date(dat_new$Date, format="%d/%m/%Y"),"%Y") 
write.csv(dat_new,"D:/PhD/Research MG/Skewness/MS_Stocks_Asset Class_Ret_Data/Full 3.csv")


#drop stocks delisted before 1995
dat<-read.csv("D:/PhD/Research MG/Skewness/MS_Stocks_Asset Class_Ret_Data/Full1.csv")
length(unique(dat$SecId))

dat1<-dat%>%
  filter(dat$Delisting.Date[1]>"1/1/1995")

#check num of na returns
nrow(dat[is.na(dat$Return)==FALSE,])
dat1<-dat[dat$SecId=="0P00000002",]
dat1<-dat1[order(dat1$Year),]

#merge inception date and returns
dat<-read.csv("D:/PhD/Research MG/Skewness/MS_Stocks_Asset Class_Ret_Data/Full1.csv")
dat1<-read.csv("D:/PhD/Research MG/Data/Morningstar Direct/STOCKS/Inception Date.csv")

dat2<-merge(dat,dat1,by="SecId")

dat3<-dat2%>%
  filter(dat2$Inception.Date>="1995-01-01")

length(unique(dat$SecId))
length(unique(dat3$SecId))

ux<-unique(dat$SecId)
ux1<-unique(dat3$SecId)
check<-setdiff(ux,ux1)
check[590]

write.csv(dat3,"D:/PhD/Research MG/Skewness/MS_Stocks_Asset Class_Ret_Data/Stocks_inception_After_95.csv")



#Checking
i<-1
datcheck<-dat3[dat3$SecId==ux[i],]
datcheck<-datcheck[order(datcheck$Year,datcheck$Month),]


I<-as.Date(dat3[dat3$SecId==ux[i],]$Inception.Date[1])
Year_I<-format(as.Date(I, format="%d/%m/%Y"),"%Y")
Month_I<-as.numeric(format(as.Date(I, format="%d/%m/%Y"),"%m"))
D<-dat3[dat3$SecId==ux[i],]$Delisting.Date[1]
Year_D<-as.numeric(substr(D,nchar(D)-3,nchar(D)))
Month_D<-as.numeric(substr(D,1,unlist(gregexpr('/',D))[1]-1))

dat4<-datcheck

if(nchar(D)!=0 & nchar(I)!=0)
{
dat4<-dat4%>%
  filter(Year>=Year_I & Year<=Year_D)
dat4<-dat4[!(dat4$Year==Year_I & dat4$Month<Month_I),]
dat4<-dat4[!(dat4$Year==Year_D & dat4$Month>Month_D+1),]
if(is.na(dat4$Return[1])==TRUE)
{
  dat4<-dat4[-1,]
}

if(is.na(dat4$Return[nrow(dat4)])==TRUE)
{
  dat4<-dat4[-nrow(dat4),]
}
}

if(nchar(D)==0 & nchar(I)!=0)
{
    dat4<-dat4%>%
      filter(Year>=Year_I)
    dat4<-dat4[!(dat4$Year==Year_I & dat4$Month<Month_I),]
    
    if(is.na(dat4$Return[1])==TRUE)
    {
      dat4<-dat4[-1,]
    }
}

if(nchar(D)!=0 & nchar(I)==0)
{
  dat4<-dat4%>%
    filter(Year<=Year_D)
  dat4<-dat4[!(dat4$Year==Year_D & dat4$Month>Month_D+1),]

  if(is.na(dat4$Return[nrow(dat4)])==TRUE)
  {
    dat4<-dat4[-nrow(dat4),]
  }
}

#drop the years for stocks before inception after delisting
a<-nrow(dat3[is.na(dat3$Return)==TRUE,])
ux<-unique(dat3$SecId)

for(i in 2:length(ux))
{
  I<-as.Date(dat3[dat3$SecId==ux[i],]$Inception.Date[1])
  Year_I<-format(as.Date(I, format="%d/%m/%Y"),"%Y")
  Month_I<-format(as.Date(I, format="%d/%m/%Y"),"%m")
  
  D<-dat3[dat3$SecId==ux[i],]$Delisting.Date[1]
  Year_D<-as.numeric(substr(D,nchar(D)-3,nchar(D)))
  Month_D<-as.numeric(substr(D,1,unlist(gregexpr('/',D))[1]-1))
  
  dat4<-dat3[dat3$SecId==ux[i],]
  
  if(nchar(D)!=0 & nchar(I)!=0)
  {
    dat4<-dat4%>%
      filter(Year>=Year_I & Year<=Year_D)
    dat4<-dat4[!(dat4$Year==Year_I & dat4$Month<Month_I),]
    dat4<-dat4[!(dat4$Year==Year_D & dat4$Month>Month_D+1),]
    if(is.na(dat4$Return[1])==TRUE)
    {
      dat4<-dat4[-1,]
    }
    
    if(is.na(dat4$Return[nrow(dat4)])==TRUE)
    {
      dat4<-dat4[-nrow(dat4),]
    }
  }
  
  if(nchar(D)==0 & nchar(I)!=0)
  {
    dat4<-dat4%>%
      filter(Year>=Year_I)
    dat4<-dat4[!(dat4$Year==Year_I & dat4$Month<Month_I),]
    
    if(is.na(dat4$Return[1])==TRUE)
    {
      dat4<-dat4[-1,]
    }
  }
  
  if(nchar(D)!=0 & nchar(I)==0)
  {
    dat4<-dat4%>%
      filter(Year<=Year_D)
    dat4<-dat4[!(dat4$Year==Year_D & dat4$Month>Month_D+1),]
    
    if(is.na(dat4$Return[nrow(dat4)])==TRUE)
    {
      dat4<-dat4[-nrow(dat4),]
    }
  }
  
  dat_final<-rbind(dat_final,dat4)
  
}


#skewness
dat<-read_dta("D:/PhD/Research MG/Skewness/CRSP_STOCKS_BM/CRSP_STOCKS.dta")
dat<-dat[is.na(dat$RET)==FALSE,]
length(unique(dat$PERMNO))

mean(dat$return)
median(dat$return)
skewness(dat$return)
dat1<-dat$return[dat$return>0]
(length(dat1)/nrow(dat))*100

x<-density(dat$RET)
plot(x,col="blue",lwd=5,main="Distribution of monthly returns", xlab = "% return", ylab="density")


