
dat<-read.csv("C:/Users/RUPSHA DEY/OneDrive - USNH/My Research_NEW/Data/morningstar_2023/MS_MANAGER/Current manager Active OE.csv")
ux<-unique(dat$performance_id)
dat_f<-data.frame(matrix(nrow=0,ncol=0))

for (f in 1:length(ux))
{
  dat_new<-fromJSON(dat$college_education_detail[1])
  dat_new$id<-ux[f]
  dat_f<-rbind(dat_f,dat_new)
}

colnames(dat_f)<-c("degree","manager_id","school","major","grad_year","performance_id")

