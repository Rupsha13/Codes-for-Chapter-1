
library("haven")
library("dplyr")

#read the full dataset
home<-"C:/Users/RUPSHA DEY/OneDrive - USNH/Research_Data/Clean data/"
home<-Sys.getenv("HOME")
dat1<-read_dta(file.path(home, "crsp_ms_4_2.dta"))
time<-read_dta(file.path(home,"time.dta"))
time<-data.frame(time)
BM<-read_dta(file.path(home,"BM_90-21.dta"))
BM<-data.frame(BM)

#declare number of simulations
B<-3000


#Create the time matrix for B simulations choosing time period from Jan 1990-Aug 2021 with replacement
date<-unique(dat1$caldt)
date<-sort(date)
date<-as.Date(date)


#style=asset class
style<-"Large Blend"
st_bm<-"MktRF"


  cat("Begin style ", style,"\n")
  
  
  dat<-dat1[dat1$style==style,]
  ux<-unique(dat$a1)
  dat$RF_ret<-dat$RF_sum_wt_gross_ret
  dat$RF_BM_ret<-dat$MktRF
  
  
  #declare the matrix where we store the results
  mat<-data.frame(matrix(nrow=length(ux),ncol=3)) #actual
  colnames(mat)<-c("Fund","alpha","t_alpha")
  mat_bs<-data.frame(matrix(nrow=0,ncol=6)) #simulated
  colnames(mat_bs)<-c("Fund","alpha","t_alpha","SD","beta","R_sqr")
  
    
  
  for (i in 1:length(ux))
  {
    
    ER_dat<-dat$RF_ret[dat$a1==ux[i]]
    MR_dat<-dat$RF_BM_ret[dat$a1==ux[i]]
    SMB_dat<-dat$SMB[dat$a1==ux[i]]
    HML_dat<-dat$HML[dat$a1==ux[i]]
    MOM_dat<-dat$MOM[dat$a1==ux[i]]
    Time_dat<-dat$caldt[dat$a1==ux[i]]
    
    ER_dat<-as.numeric(unlist(ER_dat))
    MR_dat<-as.numeric(unlist(MR_dat))
    SMB_dat<-as.numeric(unlist(SMB_dat))
    HML_dat<-as.numeric(unlist(HML_dat))
    MOM_dat<-as.numeric(unlist(MOM_dat))
    
    dat_new<-data.frame(Time_dat,ER_dat,MR_dat,SMB_dat,HML_dat,MOM_dat)
    dat_new<-na.omit(dat_new)
    dat_new<-dat_new %>% arrange(Time_dat)
    
    
    if(nrow(dat_new)<12)
    {
      next
    }

    
    #regression to find four factor alpha 
    reg<-lm(ER_dat~MR_dat+SMB_dat+HML_dat+MOM_dat,data=dat_new)
    mat[i,1]<-ux[i]
    mat[i,2]<-summary(reg)$coefficients[1,1]
    mat[i,3]<-summary(reg)$coefficients[1,3]
    res<-reg$residuals
    alpha<-summary(reg)$coefficients[1,1]
    beta1<-summary(reg)$coefficients[2,1]
    beta2<-summary(reg)$coefficients[3,1]
    beta3<-summary(reg)$coefficients[4,1]
    beta4<-summary(reg)$coefficients[5,1]
    dat_pseudo<-data.frame(dat_new$Time_dat,res)
    dat_pseudo<-dat_pseudo %>% arrange(dat_new.Time_dat)

    for (b in 1:B)
    {
      
      dat_boot<-data.frame(matrix(nrow=nrow(time),ncol=6))
      colnames(dat_boot)<-c("date","BM","SMB","HML","MOM","res")
      r<-match(time[,b],dat_pseudo$dat_new.Time_dat)
      dat_boot[,1]<-BM$caldt
      dat_boot[,2]<-BM[[st_bm]]
      dat_boot[,2:5]<-BM[,3:5]
      dat_boot[,6]<-r
      dat_boot<-na.omit(dat_boot)
      dat_boot$res<-dat_pseudo$res[dat_boot$res]
      dat_boot[,2]<-dat_boot[,2]*beta1
      dat_boot[,3]<-dat_boot[,3]*beta2
      dat_boot[,4]<-dat_boot[,4]*beta3
      dat_boot[,5]<-dat_boot[,5]*beta4
      dat_boot$ER_hat<-rowSums(dat_boot[,2:6])

      
      if (nrow(dat_boot)>8)
      {
        reg_boot<-lm(ER_hat~BM+SMB+HML+MOM,dat=dat_boot)
        
        #storing t stat of alpha and alpha
        mat_bs[nrow(mat_bs)+1,1]<-ux[i]
        mat_bs[nrow(mat_bs),2]<-summary(reg_boot)$coefficients[1,1]
        mat_bs[nrow(mat_bs),3]<-summary(reg_boot)$coefficients[1,3]
        mat_bs[nrow(mat_bs),4]<-summary(reg_boot)$coefficients[1,2]
        mat_bs[nrow(mat_bs),5]<-summary(reg_boot)$coefficients[2,1]
        mat_bs[nrow(mat_bs),6]<-summary(reg_boot)$r.squared

      }
      else
      {
        #storing t stat of alpha and alpha
        mat_bs[nrow(mat_bs)+1,1]<-ux[i]
        mat_bs[nrow(mat_bs),2]<-NA
        mat_bs[nrow(mat_bs),3]<-NA
        mat_bs[nrow(mat_bs),4]<-NA
        mat_bs[nrow(mat_bs),5]<-NA
        mat_bs[nrow(mat_bs),6]<-NA

      }
      
    }
    
  }
  
  #please mention the path here
  write_dta(mat,"ACT_LCB_GROSS_MK.dta")
  write_dta(mat_bs,"BS_LCB_GROSS_MK.dta")
  
  
  


