#GROSS RETURN AND MARKET BENCHMARK

library("haven")

#read the full dataset
home<-Sys.getenv("HOME")
dat1<-read_dta(file.path(home, "crsp_ms_4_1.dta"))
time<-read_dta(file.path(home,"time_3.dta"))
time<-data.frame(time)
#in matrix 'time' 380 months are sampled with replacement in the rows and each column represents each bootstrap sim


#declare number of simulations
B<-2000


#style=asset class
style<- "Large Blend"


cat("Begin style, return and benchmark ", style,"GROSS return","Market BM","\n")

dat<-dat1[dat1$style==style,]
ux<-unique(dat$a1)
dat$RF_ret<-dat$RF_sum_wt_gross_ret
dat$RF_BM_ret<-dat$MktRF


  
  #declare the matrix where we store the results
  mat<-data.frame(matrix(nrow=length(ux),ncol=3)) #actual
  colnames(mat)<-c("Fund","alpha","t_alpha")
  mat_bs<-data.frame(matrix(nrow=0,ncol=6)) #simulated
  colnames(mat_bs)<-c("Fund","alpha","t_alpha","SD","beta","R_sqr")
  
  #begin loop for each fund
  for (i in 1:length(ux))
  {
    
    ER_dat<-dat$RF_ret[dat$a1==ux[i]]
    MR_dat<-dat$RF_BM_ret[dat$a1==ux[i]]
    SMB_dat<-dat$SMB[dat$a1==ux[i]]
    HML_dat<-dat$HML[dat$a1==ux[i]]
    MOM_dat<-dat$MOM[dat$a1==ux[i]]
    Time_dat<-dat$caldt[dat$a1==ux[i]]
    
    ER_dat<-as.numeric(unlist(ER_dat))
    MR_dat<-as.numeric(unlist(MR_dat))
    SMB_dat<-as.numeric(unlist(SMB_dat))
    HML_dat<-as.numeric(unlist(HML_dat))
    MOM_dat<-as.numeric(unlist(MOM_dat))
    
    dat_new<-data.frame(Time_dat,ER_dat,MR_dat,SMB_dat,HML_dat,MOM_dat)
    dat_new<-na.omit(dat_new)
    
    #regression to find actual four factor alpha 
    reg<-lm(ER_dat~MR_dat+SMB_dat+HML_dat+MOM_dat,data=dat_new)
    
    #store the actual t alpha and alpha
    mat[i,1]<-ux[i]
    mat[i,2]<-summary(reg)$coefficients[1,1]
    mat[i,3]<-summary(reg)$coefficients[1,3]
    
    #create a world where alpha=0
    ER_zero<-ER_dat-summary(reg)$coefficients[1,1]
    dat_pseudo<-data.frame(Time_dat,ER_zero,MR_dat,SMB_dat,HML_dat,MOM_dat)
    
    #begin bootstrap simulations
    for (b in 1:B)
    {
      
      #match the existing time period of the fund with the selected months in time matrix above for the bootstarp simulation B
      r<-match(time[,b],dat_pseudo$Time_dat) 
      dat_boot<-data.frame(dat_pseudo[r,])
      dat_boot<-na.omit(dat_boot) #all 380 months may not be present for this fund so omit the NAs
      
      #must have at least 8 rows to be considered for bootstrap simulation
      if (nrow(dat_boot)>8)
      {
        #find simulated alpha
        reg_boot<-lm(ER_zero~MR_dat+SMB_dat+HML_dat+MOM_dat,dat=dat_boot)
        
        #storing the simulated t stat of alpha and alpha
        mat_bs[nrow(mat_bs)+1,1]<-ux[i]
        mat_bs[nrow(mat_bs),2]<-summary(reg_boot)$coefficients[1,1]
        mat_bs[nrow(mat_bs),3]<-summary(reg_boot)$coefficients[1,3]
        mat_bs[nrow(mat_bs),4]<-summary(reg_boot)$coefficients[1,2]
        mat_bs[nrow(mat_bs),5]<-summary(reg_boot)$coefficients[2,1]
        mat_bs[nrow(mat_bs),6]<-summary(reg_boot)$r.squared
      }
      else
      {
        #storing simulated t stat of alpha and alpha
        mat_bs[nrow(mat_bs)+1,1]<-ux[i]
        mat_bs[nrow(mat_bs),2]<-NA
        mat_bs[nrow(mat_bs),3]<-NA
        mat_bs[nrow(mat_bs),4]<-NA
        mat_bs[nrow(mat_bs),5]<-NA
        mat_bs[nrow(mat_bs),6]<-NA
        
      }
      
    }
    
  }   
  
  #please mention the path here
  write_dta(mat,"LCB_GROSS_MK_ACT_1.dta")
  write_dta(mat_bs,"LCB_GROSS_MK_BS_1.dta")

  

